import React from 'react';
import { Chart } from 'react-google-charts';

const IndiaGeoChart = () => {
  // Sample data (replace with actual data)
  const data = [
    ['State', 'Value'],
    ['Andhra Pradesh', 30],
    ['Arunachal Pradesh', 50],
    ['Assam', 40],
    ['Bihar', 60],
    ['Chhattisgarh', 70],
    ['Goa', 90],
    ['Gujarat', 20],
    ['Haryana', 55],
    ['Himachal Pradesh', 65],
    ['Jharkhand', 80],
    ['Karnataka', 60],
    ['Kerala', 75],
    ['Madhya Pradesh', 45],
    ['Maharashtra', 25],
    ['Manipur', 35],
    ['Meghalaya', 50],
    ['Mizoram', 70],
    ['Nagaland', 30],
    ['Odisha', 60],
    ['Punjab', 85],
    ['Rajasthan', 95],
    ['Sikkim', 55],
    ['Tamil Nadu', 45],
    ['Telangana', 60],
    ['Tripura', 40],
    ['Uttar Pradesh', 80],
    ['Uttarakhand', 70],
    ['West Bengal', 65],
  ];

  const options = {
    region: 'IN', // Focus only on India
    displayMode: 'regions', // Show states of India
    resolution: 'provinces', // Granularity for regions (states in India)
    colorAxis: { colors: ['#e0f7fa', '#00695c'] }, // Color gradient based on data
    tooltip: { trigger: 'none' }, // Disable tooltip
    backgroundColor: '#ffffff', // Background color
    datalessRegionColor: '#f0f0f0', // Color for regions with no data
    defaultColor: '#e0e0e0', // Default color for empty regions
    annotations: {
      textStyle: {
        fontSize: 12, // Text size
        color: '#000000', // Text color
        bold: true,
      },
      // Adding text annotations to specific regions (states) on the map
      12: { // Andhar Pradesh - use the state index or manually place the regions
        style: 'point',
        x: 0.5, // Adjust positioning if needed
        y: 0.5, 
        text: 'Andhra Pradesh', // Text for the state
      },
      13: { 
        style: 'point',
        x: 0.7,
        y: 0.4,
        text: 'Arunachal Pradesh',
      },
      // Add more annotations for other states as necessary
    },
    keepAspectRatio: true, // Maintain aspect ratio
    height: '500px',
    width: '100%',
  };

  return (
    <div>
      <h3>India Geo Chart with Text Labels on Map</h3>
      <Chart
        chartType="GeoChart"
        width="100%"
        height="500px"
        data={data}
        options={options}
      />
    </div>
  );
};

export default IndiaGeoChart;
